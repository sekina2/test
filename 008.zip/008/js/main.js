var ratio; // 设备像素比
var can; // 画布
var ctx; // 画布场景
var canWidth; // 画布宽
var canHeight; // 画布高

var circleCX; // 圆环圆心X
var circleCY; // 圆环圆心Y
var circleR; // 圆环半径
var circleLineW; // 圆环线宽

var circleImage; //圆环图片

var head; // 页面头部对象
var subject; //页面内容对象

var timer; // 定时器

var fontS; // 字体大小

var isRotating; // 是否正在旋转,true表示正在旋转

 document.body.onload = init;

 function init(){
    ratio = window.devicePixelRatio;    
	can = document.getElementById('canvas');
	ctx = can.getContext('2d');
    canWidth = can.width;
    canHeight = can.height;

    circleCX = canWidth*0.5;
    circleCY = canHeight*0.5;
    circleR = canHeight*0.25;
    circleLineW = circleR*0.15;

    fontS = 17*ratio;
    ctx.font = fontS+'px 黑体'; // 设置绘制的文字的字体及大小

    circleImage = new Image();
    circleImage.src = './src/pill'+(localStorage.subjectIndex==undefined?0:localStorage.subjectIndex)+'.jpg';

    // 监听触摸事件
    can.addEventListener('touchstart',touchEven,false);

    
    head = new headObj();
    head.init();
    subject = new subjectObj();
    subject.init();
	
    circleImage.onload=function(){
    ctx.save();
	ctx.beginPath();
	ctx.strokeStyle="#e0e1dc";
	ctx.arc(circleCX,circleCY,circleR*0.925,0,Math.PI*2);
	ctx.stroke();
	ctx.clip();
	ctx.drawImage(circleImage,(circleCX-circleR*0.95),(circleCY-circleR*0.95),(circleR*1.9),(circleR*1.9));
	ctx.restore();
		
	}

    head.draw(true);

    isRotating = false; //初始化是不旋转

    // 初始化页面内容部分
    var subjectIndex = localStorage.subjectIndex==undefined?0:localStorage.subjectIndex;
    var subjectscon=document.getElementById('subjectscon');
		subjectscon.innerHTML=subject.contentArr[subjectIndex];

	// 绘制点击区域
	// drawTouchArea();
}

// 触摸事件
function touchEven(e){

	if (isRotating) {return;}

		// 触摸事件的触摸点是一个数组，取数组中的第一个元素
		var touch = e.touches[0];
		var tx = ratio*touch.clientX; // 触摸点X
		var ty = ratio*touch.clientY; // 触摸点Y

		var touchAreaH = 50*ratio; // 点击区域的高度


		// 左边矩形框
		var lx1 = 0;
		var lx2 = circleCX - circleR;
		var ly1 = circleCY+(circleR+circleLineW*2)*Math.sin(Math.PI*7/6)-touchAreaH;
		var ly2 = ly1+touchAreaH;
		if (inOboundary(tx, ty, lx1, lx2, ly1, ly2)) {
			head.rotationAngle = 0;
			head.arcColor = "#e0e1dc"; // 点击旋转时将圆弧的颜色变为和圆环颜色一样
			timer = setInterval(function(){head.clickLeftRotation();},20);
			isRotating = true; //触摸点在操作范围内执行旋转
		}

		// 右边矩形框
		var rx1 = circleCX + circleR;
		var rx2 = canWidth;
		var ry1 = ly1;
		var ry2 = ly2;
		if (inOboundary(tx, ty, rx1, rx2, ry1, ry2)) {
			head.rotationAngle = 0;
			head.arcColor = "#e0e1dc";
			timer = setInterval(function(){head.clickRightRotation();},20);
			isRotating = true; //触摸点在操作范围内执行旋转
		}

		// console.log('tx:'+tx+'---ty:'+ty+'---rx1:'+rx1+'---rx2:'+rx2+'---ry1:'+ry1+'---ry2:'+ry2);
	}


// 检测某个点是否在指定矩形框内
function inOboundary(arrX, arrY, l, r, t, b) { //在l r t b范围内的检测
	return arrX > l && arrX < r && arrY > t && arrY < b;
}

// 绘制点击区域
function drawTouchArea(){
		var touchAreaH = 50*ratio; // 点击区域的高度
		var lx1 = 0;
		var lx2 = circleCX - circleR;
		var ly1 = circleCY+(circleR+circleLineW*2)*Math.sin(Math.PI*7/6)-touchAreaH;
		var ly2 = ly1+touchAreaH;
		ctx.strokeStyle='#d21414';
		ctx.strokeRect(lx1,ly1,lx2-lx1,ly2-ly1);
}





