var subjectObj = function()
{
	this.contentArr=[]; //定义3种内容存数组里
}

//初始化数组内容
subjectObj.prototype.init = function() 
{
	this.contentArr=
	[
		'<ul><li onClick="clickEvent(0)"><p class="left">对乙酰氨基酚</p><p class="right">></p></li>\
		<li onClick="clickEvent(1)"><p class="left">布洛芬</p><p class="right">></p></li>\
		<li onClick="clickEvent(2)"><p class="left">尼美舒利</p><p class="right">></p></li>\
		<li onClick="clickEvent(3)"><p class="left">赖氨匹林</p><p class="right">></p></li>\
		<li onClick="clickEvent(4)"><p class="left">特别提醒</p><p class="right">></p></li></ul>\
	',
		'<ul><li onClick="clickEvent(5)"><p class="left">小儿发热病因</p><p class="right">></p></li>\
		<li onClick="clickEvent(6)"><p class="left">发热程度及时长</p><p class="right">></p></li>\
		<li onClick="clickEvent(7)"><p class="left">发热的常见热型</p><p class="right">></p></li>\
		<li onClick="clickEvent(8)"><p class="left">发热的分期</p><p class="right">></p></li>\
		<li onClick="clickEvent(9)"><p class="left">发热的伴随体征</p><p class="right">></p></li></ul>\
	',
		'<ul><li onClick="clickEvent(10)"><p class="left">35%酒精擦浴</p><p class="right">></p></li>\
		<li onClick="clickEvent(11)"><p class="left">用温水洗澡</p><p class="right">></p></a></li>\
		<li onClick="clickEvent(12)"><p class="left">热水泡脚</p><p class="right">></p></li>\
		<li onClick="clickEvent(13)"><p class="left">冰袋冷敷</p><p class="right">></p></li>\
		<li onClick="clickEvent(14)"><p class="left">冰枕</p><p class="right">></p></li></ul>\
	'
	];
}

