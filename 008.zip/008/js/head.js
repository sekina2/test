var headObj = function(){
	this.v; // 转动速度（弧度）,点击左边时速度为负值，点击右边时速度为正值
	this.arcColor; // 圆弧颜色
	this.rotationAngle; // 转动角度
	this.stickL; // 突出部分的长度
	this.stickR; // 突出部分的圆半径
	this.circleTitles = []; // 圆环标题文字
	this.circleImage=[]; //圆环图片数组
	this.currentImg; // 当前图片下标
	this.titleW = []; // 标题宽度
	this.titleH; // 标题高度
	this.titleDistance; // 标题中心离圆心距离
	this.angle = [];
}

// 初始化
headObj.prototype.init=function()
{
	this.v = 0.1;
	this.arcColor = '#7dcced';
	this.rotationAngle = 0;
	this.isClickLeft = false;
	this.stickL = circleLineW;
	this.stickR = circleLineW*0.3;
	this.circleTitles = ['退烧药','发烧因素','物理降温'];
	this.titleH = ratio*0;
	this.titleDistance = circleR*1.8;

	var subject = localStorage.subjectIndex==undefined?0:localStorage.subjectIndex;

	for (var i = 0; i < 3; i++) 
	{
		this.circleImage[i] = new Image();
    	this.circleImage[i].src = ["./src/pill"+i+".jpg"];
		this.angle[i]=Math.PI/2+Math.PI*2/3*(i-subject);
		if (this.angle[i] < 0) {this.angle[i] += Math.PI*2;} // 保证在[0,2π]范围内
		this.titleW[i]=this.circleTitles[i].length*fontS; // title的宽度等于title的文字数量乘以字体大小
	}

	this.currentImg = subject;

}

// ============绘制图形============
headObj.prototype.draw=function(isInit){
	
	ctx.clearRect(0,0,canWidth,canHeight); 	
	if (!isInit) {	
	ctx.save();
	ctx.beginPath();
	ctx.strokeStyle="#e0e1dc";
	ctx.arc(circleCX,circleCY,circleR,0,Math.PI*2);
	ctx.stroke();
	ctx.clip();
	ctx.drawImage(this.circleImage[this.currentImg],(circleCX-circleR*0.95),(circleCY-circleR*0.95),(circleR*1.9),(circleR*1.9));
	ctx.restore();
}
	this.drawCircle();
	this.drawArc();


	for (var i = 0; i < 3; i++) 
	{
		this.drawStick(this.angle[i]);
		this.drawText(i);
	}
}

// 绘制圆环
headObj.prototype.drawCircle=function(){

	ctx.beginPath();
	ctx.strokeStyle="#e0e1dc";
	ctx.lineWidth=circleLineW;
	ctx.arc(circleCX,circleCY,circleR,0,Math.PI*2);	
	ctx.stroke();
	ctx.closePath();
}

// 绘制圆弧
headObj.prototype.drawArc=function(){
	ctx.beginPath();
	ctx.strokeStyle=this.arcColor;
	ctx.lineWidth=circleLineW;
	ctx.lineCap='round';
	ctx.arc(circleCX,circleCY,circleR,Math.PI/6,5*Math.PI/6,false);
	ctx.stroke();
	ctx.closePath();
}


// 绘制突出部分
headObj.prototype.drawStick=function(angle){
	var color = (angle>=Math.PI/2-this.v && angle <= Math.PI/2+this.v)?'#7dcced':'#e0e1dc';
	ctx.beginPath();
	ctx.strokeStyle=color;
	ctx.lineWidth=circleLineW*0.3;
	ctx.moveTo(circleCX+(circleR+circleLineW*0.5)*Math.cos(angle),circleCY+(circleR+circleLineW*0.5)*Math.sin(angle));
	ctx.lineTo(circleCX+(circleR+circleLineW+this.stickL)*Math.cos(angle),circleCY+(circleR+circleLineW+this.stickL)*Math.sin(angle));
	ctx.stroke();
	// ctx.closePath();

	ctx.beginPath();
	ctx.fillStyle=color;
	ctx.arc(circleCX+(circleR+circleLineW+this.stickL)*Math.cos(angle),circleCY+(circleR+circleLineW+this.stickL)*Math.sin(angle),this.stickR,0,Math.PI*2);
	ctx.fill();
	ctx.closePath();

}

//绘制文字
headObj.prototype.drawText=function(i){
	var angle = this.angle[i];
	var title = this.circleTitles[i];
	var color = (angle>=Math.PI/2-this.v && angle <= Math.PI/2+this.v)?'#7dcced':'#b8b9b5';
	var titleCX = circleCX+this.titleDistance*Math.cos(angle); // 文字中心X
	var titleCY = circleCY+this.titleDistance*Math.sin(angle); // 文字中心Y
	var titleX = titleCX-this.titleW[i]*0.5; // 文字X
	var titleY = titleCY-this.titleH*0.5; // 文字Y

	ctx.save();
	ctx.fillStyle = color; 
	ctx.fillText(title,titleX,titleY);
	ctx.restore();

	//更新内容
	if (angle>=Math.PI/2-this.v && angle <= Math.PI/2+this.v) 
	{
		var subjectscon=document.getElementById('subjectscon');
		subjectscon.innerHTML=subject.contentArr[i];
		this.currentImg = i;
		// 将当前状态保存，当从下一页面返回该页面时读取该状态
		localStorage.removeItem("subjectIndex");
		localStorage.setItem("subjectIndex",i);
	}

}

// ============点击旋转============
// 点击右边旋转
headObj.prototype.clickRightRotation=function(){
	var v = this.v;
	this.rotationAngle += this.v;
	if (this.rotationAngle >= Math.PI*2/3) 
	{
		v = Math.PI*2/3-(this.rotationAngle - this.v);
		this.arcColor = '#7dcced'; // 旋转结束时将圆弧颜色恢复为蓝色
		clearInterval(timer);
		isRotating = false; //旋转结束后将开关关闭
	}
	for (var i = 0; i < 3; i++) 
	{
		this.angle[i] += v;
		if (this.angle[i] > Math.PI*2) 
		{
			this.angle[i] -= Math.PI*2;
		}
	}
	this.draw(false);
}


// 点击左边旋转
headObj.prototype.clickLeftRotation=function(){
	var v = this.v;
	this.rotationAngle -= this.v;
	if (this.rotationAngle <= -Math.PI*2/3) 
	{
		v = Math.PI*2/3+this.rotationAngle + this.v;
		this.arcColor = '#7dcced'; // 旋转结束时将圆弧颜色恢复为蓝色
		clearInterval(timer);
		isRotating = false; //旋转结束后将开关关闭
	}
	for (var i = 0; i < 3; i++) 
	{
		this.angle[i] -= v;
		if (this.angle[i] < 0) 
		{
			this.angle[i] += Math.PI*2;
		}
	}
	this.draw(false);
}









